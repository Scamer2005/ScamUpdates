# ScamUpdates

Zentraler Update-Manager für Paper **1.21.11**: erkennt installierte Plugins, sucht Updates (Modrinth, Hangar, SpigotMC/Spiget, GitHub Releases, Jenkins, direkte Links), lädt sie geprüft nach `plugins/update/`, sichert die alte JAR in `plugins/update-backup/`, bietet Rollback und löst den Neustart über die **Crafty-Controller-REST-API** aus.

> ## Status dieses Projekts (bitte lesen)
> Der Quellcode wurde **ohne Compiler geschrieben**: In der Umgebung, in der er entstand, gab es weder JDK noch Gradle noch Netzwerkzugriff. Er wurde **weder kompiliert noch wurden die Tests ausgeführt**. Geprüft wurde nur: Klammerbalance, Paket-/Dateinamen, die `config.yml` als gültiges YAML und dass alle aufgerufenen Methoden definiert sind.
> **Rechne mit einzelnen Compilerfehlern oder fehlschlagenden Tests beim ersten Build.** Schick mir die Fehlermeldungen, dann behebe ich sie. Die Paper-API-Details (`PluginMeta`, `Bukkit.getUpdateFolderFile()`, `Bukkit.getCommandMap()`, Comment-API der `YamlConfiguration`) stammen aus der Erinnerung an die Paper-API, nicht aus einer Prüfung gegen 1.21.11.

## Bauen mit IntelliJ

1. Ordner `ScamUpdates` als Gradle-Projekt öffnen (*File → Open → build.gradle*).
2. *Settings → Build Tools → Gradle → Gradle JDK*: JDK 21 oder neuer (25 funktioniert; das Bytecode-Ziel ist per `options.release = 21` fest auf Java 21).
3. Gradle-Version: Wähle in IntelliJ *Use Gradle from: 'gradle-wrapper.properties'* (Gradle 9.2.0 eingetragen) oder eine installierte Gradle-Version ≥ 9.1 (nötig, wenn du mit JDK 25 baust). **`gradlew`/`gradle-wrapper.jar` fehlen**, weil Binärdateien ohne Netzwerk nicht erzeugt werden konnten. Mit installiertem Gradle erzeugst du sie per `gradle wrapper`.
4. Tests: Gradle-Task `test`. Bauen: Task `build` → `build/libs/ScamUpdates.jar` (zusätzlich Kopie nach `dist/ScamUpdates.jar`).
5. Abhängigkeit: ausschließlich `io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT` (`compileOnly`, Repository `https://repo.papermc.io/repository/maven-public/`). Adventure/MiniMessage, Gson und SnakeYAML liefert Paper zur Laufzeit mit; es wird nichts eingebettet. Tests nutzen JUnit 5 und den im JDK enthaltenen `com.sun.net.httpserver` als Mock für Crafty.

## Installation

1. `ScamUpdates.jar` nach `plugins/` kopieren, Server starten (das Plugin lädt, bleibt aber **deaktiviert**, bis Crafty konfiguriert ist).
2. `plugins/ScamUpdates/config.yml` öffnen. Die Anleitung steht als Kommentare direkt über den Crafty-Einstellungen.
3. `crafty.connection.base-url`, `api-token`, `server-id` eintragen (SSL siehe unten).
4. `/scamupdates config reload` oder Server neu starten, dann `/scamupdates status` (Soll: `ACTIVE`).

## Startablauf (verbindliche Reihenfolge)

1. Plugin lädt. 2. Config wird gelesen, migriert, validiert (Fehler → `DISABLED_CONFIGURATION_ERROR`). 3. Crafty-Angaben vollständig? Sonst `DISABLED_MISSING_CONFIG`. 4. Internetprüfung (asynchron, mehrere HTTPS-Ziele; ein einzelner Ausfall zählt nicht; unterschieden werden DNS-Fehler, Timeout, TLS-Fehler, keine Verbindung) → sonst `DISABLED_NO_INTERNET`. 5. Crafty-Verbindung und Authentifizierung (`GET …/servers/<id>`) → `DISABLED_CRAFTY_UNAVAILABLE` bzw. `DISABLED_CRAFTY_AUTH_FAILED` (falsche Server-ID: `DISABLED_CONFIGURATION_ERROR`). 6. Erst jetzt: `ACTIVE`, Prüfung der zuletzt vorgemerkten Updates, Plugin-Erkennung und Update-Suche.

Im Fehlerzustand gibt es keine Update-Suche, keine Plugin-Erkennung zu Updatezwecken, keine Downloads, Backups, Rollbacks, Auto-Prüfungen oder Neustarts; die Services existieren dann nicht einmal. Erlaubt sind nur `help`, `status`, `config reload`, `cancel`, `later`. `config reload` führt **alle** Startprüfungen erneut aus und aktiviert das Plugin nur bei Erfolg (abschaltbar mit `startup.allow-reload-recovery: false`). Die Fehlermeldung geht an die Konsole und an Spieler mit `scamupdates.notify` (einmal pro Join), nie an normale Spieler.

## Commands

| Command | Berechtigung | Beschreibung |
|---|---|---|
| `/scamupdates`, `help` | `scamupdates.check` | Hilfe |
| `check` (Alias `/update check`) | `scamupdates.check` | Updates suchen (mit Bestätigung, Wartezeit gegen API-Limits) |
| `status` | `scamupdates.check` | Plugin-Status, Zähler, laufende Aktion |
| `list [updates\|all] [Seite]` | `scamupdates.check` | Plugins/Updates, seitenweise |
| `download` | `scamupdates.download` | Gefundene Updates laden und vormerken (Bestätigung) |
| `restore <Plugin>` / `restore all` | `scamupdates.restore` | Rollback (Bestätigung) |
| `backup list [Seite]` | `scamupdates.backup` | Backups anzeigen |
| `backup delete <Plugin>` / `delete all` | `scamupdates.backup.delete` | Backups löschen (Bestätigung) |
| `restart` | `scamupdates.restart` | Neustart über Crafty (Bestätigung + Vorprüfung) |
| `config reload` | `scamupdates.config` | Config neu laden, Startprüfungen wiederholen |
| `sources` | `scamupdates.sources` | Quellen anzeigen |
| `exclude <Plugin>` / `include <Plugin>` | `scamupdates.sources` | Ausschließen / wieder aufnehmen (Bestätigung) |
| `match [Plugin]`, `pick <Plugin> <Nr>` | `scamupdates.check` / `scamupdates.sources` | Admin-Auswahl bei mehreren Treffern; `0` = „Keins davon“ |
| `confirm <Token>`, `cancel [Token]`, `later` | – (Token-gebunden) | Bestätigen, abbrechen, später |

`scamupdates.admin` (Standard: OP) enthält alle Berechtigungen, `scamupdates.notify` steuert die Join-Nachrichten. `backup delete` benötigt `scamupdates.backup.delete`, nicht nur `scamupdates.backup`. Chat-Klicks führen ausschließlich diese Commands aus und unterliegen damit denselben serverseitigen Prüfungen. Die Berechtigung wird beim Befehl **und erneut bei der Bestätigung** geprüft. Nur Spieler und die Konsole dürfen Befehle ausführen (keine Commandblöcke).

**Alias-Kollision `/update`:** Der Alias ist als eigener Befehl `update` registriert und akzeptiert nur `check`. Belegt ein anderes Plugin `/update`, behält dieses den Namen (Bukkit-Regel); ScamUpdates schreibt dann eine Warnung ins Log, und der Alias ist als `/scamupdates:update check` erreichbar. `/scamupdates check` funktioniert immer.

## Sicherheit

* **Bestätigungen:** zeitlich begrenzte Einmal-Tokens (`confirmations.timeout-seconds`), an die UUID des ausführenden Spielers gebunden (Konsole hat eine eigene Identität), nach Gebrauch gelöscht (Doppelklick ergibt „ungültig“), pro Aktion ein Token (neue Anfrage ersetzt die alte), Limit pro Spieler. Eine globale Operationssperre verhindert parallele Downloads/Rollbacks/Neustarts. Abschalten nur bewusst per `confirmations.enabled: false` oder je Aktion.
* **Downloads:** nur HTTPS (`downloads.allow-http: false`), Größenlimit, Gesamt-Zeitlimit, Weiterleitungen auf HTTP werden abgelehnt, Temp-Datei außerhalb von `plugins/update`, danach Prüfsummen (Quelle: SHA-1/256/512; manuell: `sha256`), JAR-Validierung (Magic Bytes, Zip-Slip, `plugin.yml`/`paper-plugin.yml`, Hauptklasse vorhanden, **Pluginname muss zum Ziel passen**, `api-version` nicht neuer als der Server). Erst danach wird verschoben. Dateinamen werden gegen Path Traversal geprüft; heruntergeladene Dateien werden nie ausgeführt oder entpackt. Schlägt ein Schritt fehl, bleiben installierte JAR **und** bisheriges Backup unverändert.
* **Token:** wird nur im `Authorization`-Header an Crafty gesendet, nie geloggt (Redaktion im Logger), nie in `toString()`, nie im Chat. Crafty-Anfragen folgen keinen Weiterleitungen. SSL-Prüfung ist standardmäßig an.
* Es gibt keinen `/reload`, keine Hot-Reloads und keine Konsolenfilter. Fremde Plugin-Configs werden nicht verändert.

## Update-Vorgang

Bestätigter Download → parallel (max. `downloads.max-parallel`) laden und validieren → pro Plugin nacheinander: Backup-Kopie vorbereiten und prüfen → validierte Datei nach `plugins/update/<Dateiname der installierten JAR>` verschieben → Backup ersetzen → Eintrag in `transactions.yml`. Danach erscheint die Meldung mit **[Jetzt neu starten] [Später]**.

**Wichtig:** Der Bukkit/Paper-Update-Ordner übernimmt Dateien nur, wenn der Dateiname **identisch** mit dem der installierten JAR ist. ScamUpdates übernimmt den Namen daher von der installierten Datei (nicht den Namen der Download-Datei). Die Prüfung nach dem Neustart vergleicht den SHA-256 der installierten JAR mit der vorgemerkten Datei (unabhängig von Versionsformaten) und meldet `APPLIED`, `NOT_APPLIED` oder `MISMATCH` in Log und `/scamupdates status`.

Die Zuordnung per Namen: Läuft ein Plugin als Paper-„legacy“ mit Remapping (`plugins/.paper-remapped/`), wird die Original-JAR im `plugins`-Ordner über den Namen in der `plugin.yml` gefunden.

## Backup und Rollback

* `plugins/update-backup/` enthält pro Plugin **höchstens eine** alte JAR, benannt wie die Original-JAR. Die Zuordnung steht lesbar in `plugins/update-backup/scamupdates-backups.yml` (Plugin, Version, SHA-256, Zeitpunkt). Config-Ordner werden nie gesichert, verändert oder gelöscht; gelöscht werden nur JARs, die in diesen Metadaten stehen.
* Ein neues Backup ersetzt das alte erst, nachdem Staging gelungen ist. Backups überstehen Neustarts.
* `restore <Plugin>`: zeigt aktuelle und gesicherte Version, fragt nach Bestätigung, validiert die Backup-JAR und legt sie als Update in `plugins/update/` ab. Die aktuell installierte JAR wird dabei zum **neuen Backup** (Tausch), sodass der Rollback selbst umkehrbar ist. `restore all` zeigt alle Backups und fragt ebenfalls nach.
* Ein Plugin mit vorgemerkter Änderung (wartet auf Neustart) kann nicht erneut aktualisiert oder zurückgesetzt werden. Fehlende oder veränderte Backups werden gemeldet.
* **Manuelle Wiederherstellung, falls ScamUpdates selbst nicht mehr lädt:** Server stoppen, die gewünschte JAR aus `plugins/update-backup/` zurück nach `plugins/` kopieren (gleicher Dateiname, bestehende Datei ersetzen), Server starten. Ein Plugin kann seinen eigenen Ausfall nicht selbst reparieren; dieser Weg funktioniert ohne ScamUpdates.

## Crafty Controller

Verwendet wird die REST-API von Crafty 4 (v2) mit `Authorization: Bearer <Token>`:

* Startprüfung: `GET <base-url>/api/v2/servers/<server-id>` (200 = erreichbar, Token und Server-ID gültig; 401/403 = Authentifizierung; 404 = falsche Server-ID oder falscher API-Pfad)
* Neustart: `POST <base-url>/api/v2/servers/<server-id>/action/restart_server`

**Verifikation:** Diese Endpunkte habe ich über zwei unabhängige Open-Source-Crafty-Clients, den Crafty-Issue-Tracker und eine Doku-Zusammenfassung gegengeprüft, **nicht** über die offizielle Swagger-/API-Seite selbst, die ich nicht öffnen konnte. Die Menübezeichnungen für „API Key“ und die Rollen-Rechte in der `config.yml` sind entsprechend allgemein formuliert. Prüfe sie gegen deine Crafty-Version und die offizielle Dokumentation (`https://docs.craftycontrol.com`). Mit dem `curl`-Test aus der `config.yml` kannst du die Endpunkte sofort verifizieren.

Die Server-ID steht in der Adresszeile der Server-Detailseite (`…/panel/server_detail?id=<UUID>`). Zu SSL: gültiges Zertifikat über Reverse-Proxy (empfohlen) oder PEM-Datei in `ca-certificate-file` (Hostname muss im Zertifikat stehen); `verify-ssl: false` nur in vertrauenswürdigen Netzen.

ScamUpdates beendet den Serverprozess nie selbst und führt kein `/restart` aus. **Neustart-Ablauf:** Bestätigung → Vorprüfung (Dateien in `plugins/update` vorhanden, SHA-256 unverändert, JAR gültig, Backups vorhanden, keine laufende Transaktion) → Crafty-Aufruf → Ergebnis ins Log. Lehnt Crafty ab oder ist es nicht erreichbar, wird das gemeldet; ein Erfolg wird nie vorgetäuscht. „Crafty hat den Neustart angenommen“ heißt nur: Crafty hat die Anfrage akzeptiert.

## Updatequellen und ehrliche Grenzen

Es kann nicht jedes Plugin weltweit erkannt werden. Zuordnung: (1) manuelle Config-Zuordnung, (2) gespeicherte Zuordnung/Ausschluss, (3) Links in Website/Beschreibung der `plugin.yml`, (4) Namenssuche auf Modrinth, Hangar, Spiget (Treffer müssen den Namen exakt – normalisiert – treffen). **Mehrere Treffer werden nie automatisch gewählt**; der Admin entscheidet über `/scamupdates match`, inklusive **„Keins davon“** (wird dauerhaft in `matches.yml` gespeichert, die Suche wird nicht wiederholt; nur eine manuelle Zuordnung in der Config überschreibt das, `include` verweigert es). Bei genau einem Treffer wird automatisch zugeordnet (`matching.auto-assign-single-match`); die Namensprüfung der heruntergeladenen JAR bleibt als Schutz bestehen.

* **Modrinth, Hangar:** offizielle APIs. Hangar: nur Plattform PAPER; Modrinth liefert SHA-1/512, Hangar SHA-256.
* **SpigotMC:** SpigotMC hat keine offizielle Download-API; genutzt wird die Community-API **Spiget**. Kostenpflichtige und extern gehostete Ressourcen liefern nur den Hinweis „Update vorhanden“, keinen Direktdownload. Spigot-Downloads können durch Cloudflare scheitern; das wird als Fehler gemeldet.
* **GitHub Releases:** über die REST-API; genau ein passendes `.jar`-Asset (bei mehreren zählt der Pluginname, sonst wird die Version übersprungen). Die Repo-Suche ist nur mit Token aktiv (strenges Rate-Limit); ohne Token reichen Treffer aus der Plugin-Metadaten-Website. Ein Token wird nur an `api.github.com` gesendet.
* **Jenkins:** nur per manueller Zuordnung (`project-id` = Job-URL, optional `artifact-regex`); letzter erfolgreicher Build, Version aus dem Dateinamen, Kanal *development*. Versionsvergleich von CI-Builds ist naturgemäß unzuverlässig.
* **Direkter Link:** nur manuell; Updates werden erkannt über `sha256` (weicht von der installierten Datei ab) oder `version`.
* **GitHub Actions: nicht implementiert.** Artefakt-Downloads verlangen Authentifizierung, und es gibt keine stabile offizielle Alternative; Drittdienste wurden bewusst nicht eingebunden.
* Rate-Limits: HTTP 429 (und GitHub-403 mit `x-ratelimit-remaining: 0`) sperren den Host bis zum Ende der Wartezeit; 5xx und Netzwerkfehler werden begrenzt wiederholt; zwischen Anfragen liegt eine konfigurierbare Pause. Unbekannte Plattform-Versionsformate können falsche „kein Update“-Ergebnisse liefern.
* Plugin-Kompatibilität: Minecraft-Version (bei Modrinth/Hangar) und `api-version` der heruntergeladenen JAR werden geprüft; Abhängigkeiten anderer Plugins werden **nicht** geprüft.

## Nicht umgesetzt / Abweichungen von der Vorgabe

* **Unterdrückung fremder Update-Meldungen (Abschnitt 4) ist nicht implementiert.** Das ist keine Auslassung aus Bequemlichkeit: Es gibt keine einheitliche offizielle Schnittstelle dafür, und jede Integration müsste die Config-Schlüssel des jeweiligen Plugins kennen (z. B. `update-checker: false`). Ohne gesicherte Kenntnis der Schlüssel hätte ich Werte erfinden oder fremde Configs „blind“ ändern müssen, was die Vorgabe ausdrücklich verbietet. Das Plugin ändert deshalb keine fremden Dateien. Wenn du eine Liste konkreter Plugins nennst, kann man pro Plugin eine einzelne, backup-gesicherte Integration ergänzen.
* **Titel/Sounds:** konfigurierbar (`sounds.*`, `notifications.title.*`).
* **Config-Migration** ergänzt fehlende Schlüssel samt Kommentaren und legt `config.yml.bak-v<alt>` an; versionsspezifische Umbauten sind als Platzhalter-Hook vorbereitet (`ConfigMigrator`), da es erst Version 1 gibt.
* Plugin-Namen mit Punkt funktionieren in `plugins:` der Config nicht (YAML-Pfadtrenner).
* `check` verlangt standardmäßig eine Bestätigung (laut Vorgabe „Updates suchen“); abschaltbar unter `confirmations.actions.check`.

## Dateien

`plugins/ScamUpdates/`: `config.yml`, `matches.yml` (Zuordnungen, Ausschlüsse), `transactions.yml` (vorgemerkte Änderungen), `notified.yml` (wer wurde informiert), `logs/scamupdates.log` (rotierend, ohne Token), `tmp/` (Downloads in Arbeit, wird beim Start geleert).

## Projektstruktur

```
src/main/java/de/scamupdates/
  ScamUpdates, StartupCoordinator
  state/ config/ messaging/ logging/ net/ crafty/ security/
  model/ sources/ match/ scan/ update/ backup/ rollback/ restart/
  commands/ listeners/ utils/
src/test/java/de/scamupdates/   Tests (JUnit 5) für Versionen, JAR-Validierung, Download-Pipeline,
                                Backup/Staging, Rollback, Bestätigungen, Permissions, Internetprüfung,
                                Crafty (Mock-Server), Config-Migration, Plugin-Index, Zuordnung, Neustart-Vorprüfung
```
