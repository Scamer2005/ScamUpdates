package de.scamupdates.ops;

public enum OpType { CHECK, DOWNLOAD, RESTORE, BACKUP_DELETE, RESTART, SERVER_UPDATE }
