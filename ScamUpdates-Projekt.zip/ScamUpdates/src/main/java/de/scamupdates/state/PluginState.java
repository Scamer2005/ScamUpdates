package de.scamupdates.state;

public enum PluginState {
    STARTING,
    ACTIVE,
    DISABLED_MISSING_CONFIG,
    DISABLED_NO_INTERNET,
    DISABLED_CRAFTY_UNAVAILABLE,
    DISABLED_CRAFTY_AUTH_FAILED,
    DISABLED_CONFIGURATION_ERROR;

    public boolean isDisabled() {
        return this != STARTING && this != ACTIVE;
    }
}
