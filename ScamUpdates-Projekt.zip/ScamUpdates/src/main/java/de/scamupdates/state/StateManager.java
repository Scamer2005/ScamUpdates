package de.scamupdates.state;

import java.util.List;

/** Zentraler Plugin-Status. Alle Update-Aktionen muessen {@link #requireActive()} bestehen. */
public final class StateManager {
    private volatile PluginState state = PluginState.STARTING;
    private volatile List<String> details = List.of();

    public PluginState state() { return state; }
    public List<String> details() { return details; }
    public boolean isActive() { return state == PluginState.ACTIVE; }

    public synchronized void set(PluginState newState, List<String> newDetails) {
        this.details = List.copyOf(newDetails);
        this.state = newState;
    }

    public void requireActive() {
        if (!isActive()) {
            throw new IllegalStateException("ScamUpdates ist nicht aktiv (" + state + ")");
        }
    }
}
