package de.scamupdates;

import de.scamupdates.config.ConfigManager;
import de.scamupdates.config.CraftyConfig;
import de.scamupdates.crafty.CraftyClient;
import de.scamupdates.net.InternetCheck;
import de.scamupdates.security.Perm;
import de.scamupdates.state.PluginState;
import de.scamupdates.update.PostRestartVerifier;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Erzwingt die Startreihenfolge: Config -> Crafty-Angaben -> Internet -> Crafty-Verbindung/Auth -> ACTIVE.
 * Erst danach beginnen Plugin-Erkennung und Update-Suche. Jeder Fehlschlag fuehrt in einen Fehlerzustand.
 */
public final class StartupCoordinator {
    private final ScamUpdates plugin;
    private final AtomicInteger generation = new AtomicInteger();
    private volatile BukkitTask periodic;

    public StartupCoordinator(ScamUpdates plugin) { this.plugin = plugin; }

    /** Hauptthread. */
    public void start(boolean firstRun) {
        final int gen = generation.incrementAndGet();
        stopScheduled();
        plugin.confirmations().clear();
        plugin.dropServices();
        plugin.log().clearSecrets();
        plugin.state().set(PluginState.STARTING, List.of());
        plugin.log().info("Startpruefungen laufen ...");

        ConfigManager config = plugin.config();
        ConfigManager.LoadResult lr = config.load();
        if (!lr.ok()) { fail(PluginState.DISABLED_CONFIGURATION_ERROR, lr.problems(), gen); return; }

        CraftyConfig cc = config.crafty();
        plugin.log().registerSecret(cc.apiToken());
        plugin.log().registerSecret(config.githubToken());
        List<String> missing = cc.missingSettings();
        if (!missing.isEmpty()) { fail(PluginState.DISABLED_MISSING_CONFIG, missing, gen); return; }
        List<String> formatProblems = cc.formatProblems();
        if (!formatProblems.isEmpty()) { fail(PluginState.DISABLED_CONFIGURATION_ERROR, formatProblems, gen); return; }

        try {
            plugin.io().submit(() -> asyncChecks(cc, gen, firstRun));
        } catch (RuntimeException e) {
            plugin.log().error("Startpruefung konnte nicht gestartet werden", e);
        }
    }

    private void asyncChecks(CraftyConfig cc, int gen, boolean firstRun) {
        try {
            ConfigManager config = plugin.config();
            InternetCheck.Report rep = new InternetCheck(config.internetTargets(), Duration.ofMillis(config.internetTimeoutMs()), config.userAgent()).run();
            if (gen != generation.get()) return;
            plugin.log().debug("Internetpruefung: " + rep.describe());
            if (rep.verdict() != InternetCheck.Verdict.CONNECTED) {
                fail(PluginState.DISABLED_NO_INTERNET, List.of(reason(rep.verdict()), rep.describe()), gen);
                return;
            }
            if (rep.failures() > 0) {
                plugin.log().warn("Internet erreichbar, aber " + rep.failures() + " Pruefziel(e) nicht: " + rep.describe());
            }

            CraftyClient client;
            try {
                client = new CraftyClient(cc, plugin.log());
            } catch (IOException | GeneralSecurityException e) {
                fail(PluginState.DISABLED_CONFIGURATION_ERROR,
                        List.of("Crafty-SSL-Konfiguration fehlerhaft: " + plugin.log().redact(String.valueOf(e.getMessage()))), gen);
                return;
            }
            if (!cc.verifySsl()) plugin.log().warn("crafty.connection.verify-ssl ist false: Die Crafty-Verbindung ist NICHT gegen Abhoeren geschuetzt!");
            CraftyClient.Result r = client.verifyConnection();
            if (gen != generation.get()) return;
            switch (r.status()) {
                case OK -> { }
                case AUTH_FAILED -> { fail(PluginState.DISABLED_CRAFTY_AUTH_FAILED, List.of(r.message()), gen); return; }
                case SERVER_NOT_FOUND -> {
                    fail(PluginState.DISABLED_CONFIGURATION_ERROR,
                            List.of("Crafty kennt keinen Server mit der konfigurierten server-id (oder api-base-path ist falsch). " + r.message()), gen);
                    return;
                }
                case TLS_ERROR -> {
                    fail(PluginState.DISABLED_CRAFTY_UNAVAILABLE,
                            List.of("TLS-/Zertifikatsfehler: " + r.message() + " (siehe SSL-Hinweise in der config.yml)"), gen);
                    return;
                }
                default -> { fail(PluginState.DISABLED_CRAFTY_UNAVAILABLE, List.of(r.message()), gen); return; }
            }
            activate(client, gen, firstRun);
        } catch (Throwable t) {
            plugin.log().error("Unerwarteter Fehler bei den Startpruefungen", t);
            fail(PluginState.DISABLED_CONFIGURATION_ERROR, List.of("Unerwarteter Fehler: " + t.getClass().getSimpleName()), gen);
        }
    }

    private static String reason(InternetCheck.Verdict v) {
        return switch (v) {
            case DNS_ERROR -> "DNS-Fehler: Hostnamen konnten nicht aufgeloest werden";
            case TIMEOUT -> "Zeitueberschreitung bei allen Pruefzielen";
            case TLS_ERROR -> "TLS-/Zertifikatsfehler bei allen Pruefzielen (Uhrzeit, Proxy, Java-Zertifikate pruefen)";
            default -> "Keines der Pruefziele war erreichbar";
        };
    }

    private void activate(CraftyClient client, int gen, boolean firstRun) {
        if (gen != generation.get()) return;
        plugin.buildServices(client);          // Services zuerst ...
        plugin.state().set(PluginState.ACTIVE, List.of());  // ... dann ACTIVE
        plugin.log().info("Alle Startpruefungen bestanden. ScamUpdates ist aktiv.");

        plugin.updates().cleanTmp();
        if (firstRun) {
            List<PostRestartVerifier.Report> reports = PostRestartVerifier.verify(plugin.transactions(),
                    plugin.pluginsDir(), plugin.updateDir(), plugin.log());
            if (!reports.isEmpty()) {
                long ok = reports.stream().filter(x -> x.status() == PostRestartVerifier.Status.APPLIED).count();
                plugin.setPostRestartSummary(ok + "/" + reports.size() + " uebernommen");
            }
        }
        plugin.runMain(() -> {
            if (gen != generation.get() || !plugin.state().isActive()) return;
            schedulePeriodic();
            if (plugin.config().checkOnStart()) runAutoCheck();
        });
    }

    private void runAutoCheck() {
        if (!plugin.state().isActive() || plugin.lock().isBusy()) return;
        plugin.updates().check().whenComplete((snap, err) -> plugin.runMain(() -> {
            if (err != null) {
                plugin.log().warn("Automatische Pruefung fehlgeschlagen: " + plugin.log().redact(String.valueOf(err.getMessage())));
                return;
            }
            plugin.notifier().broadcastToOnlineAdmins();
        }));
    }

    private void schedulePeriodic() {
        int minutes = plugin.config().checkIntervalMinutes();
        if (minutes <= 0) return;
        long ticks = minutes * 60L * 20L;
        periodic = plugin.getServer().getScheduler().runTaskTimer(plugin, this::runAutoCheck, ticks, ticks);
    }

    void stopScheduled() {
        BukkitTask t = periodic;
        if (t != null) t.cancel();
        periodic = null;
    }

    private void fail(PluginState s, List<String> details, int gen) {
        if (gen != generation.get()) return;
        plugin.state().set(s, details);
        plugin.log().error("ScamUpdates deaktiviert: " + s + " - " + String.join("; ", details), null);
        plugin.runMain(() -> {
            if (gen != generation.get()) return;
            stopScheduled();
            plugin.dropServices();
            Component msg = plugin.notifier().stateErrorMessage();
            Bukkit.getConsoleSender().sendMessage(msg);
            for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                if (Perm.NOTIFY.allows(n -> p.hasPermission(n))) plugin.notifier().sendStateError(p);
            }
        });
    }

    public void shutdown() {
        generation.incrementAndGet();
        stopScheduled();
    }
}
