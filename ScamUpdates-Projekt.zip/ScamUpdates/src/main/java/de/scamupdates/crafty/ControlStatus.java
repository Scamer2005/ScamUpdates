package de.scamupdates.crafty;

/** Zustand der Serversteuerung fuer Statusanzeigen: Crafty (enabled) oder lokaler /restart. */
public record ControlStatus(boolean craftyEnabled, boolean ready, long time, String detail) {
    public static ControlStatus unknown(boolean craftyEnabled) {
        return new ControlStatus(craftyEnabled, false, 0, "noch nicht geprueft");
    }
}
