package de.scamupdates.scan;

import de.scamupdates.model.PluginInfo;
import io.papermc.paper.plugin.configuration.PluginMeta;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.List;

public final class PluginScanner {
    private PluginScanner() {}

    /** Nur auf dem Hauptthread aufrufen (Bukkit-API). Dateizugriffe passieren spaeter asynchron. */
    public static List<PluginInfo> collectMetadata() {
        List<PluginInfo> list = new ArrayList<>();
        for (Plugin plugin : Bukkit.getPluginManager().getPlugins()) {
            PluginMeta meta = plugin.getPluginMeta();
            list.add(new PluginInfo(meta.getName(), meta.getVersion(),
                    List.copyOf(meta.getAuthors()), meta.getWebsite(), meta.getDescription(),
                    codeSource(plugin), null));
        }
        return list;
    }

    private static Path codeSource(Plugin plugin) {
        try {
            CodeSource cs = plugin.getClass().getProtectionDomain().getCodeSource();
            if (cs == null || cs.getLocation() == null) return null;
            return Path.of(cs.getLocation().toURI());
        } catch (URISyntaxException | RuntimeException e) {
            return null;
        }
    }
}
