package de.scamupdates.restart;

import de.scamupdates.backup.BackupManager;
import de.scamupdates.config.ConfigManager;
import de.scamupdates.crafty.CraftyClient;
import de.scamupdates.logging.ScamLog;
import de.scamupdates.security.OperationLock;
import de.scamupdates.state.StateManager;
import de.scamupdates.update.JarValidator;
import de.scamupdates.update.TransactionStore;
import de.scamupdates.utils.AtomicFiles;
import de.scamupdates.utils.Hashing;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.function.Supplier;

/** Neustart ausschliesslich ueber die Crafty-API, nach Vorpruefung. Es wird kein Erfolg vorgetaeuscht. */
public final class RestartService {

    public enum Result { REQUESTED, PREFLIGHT_FAILED, DISABLED, NO_PENDING, FAILED, BUSY }

    public record Outcome(Result result, List<String> details) {}

    private final StateManager state;
    private final ConfigManager config;
    private final ScamLog log;
    private final OperationLock lock;
    private final ExecutorService io;
    private final TransactionStore transactions;
    private final BackupManager backups;
    private final Path updateDir;
    private final Supplier<CraftyClient> crafty;
    private final Supplier<String> mcVersion;

    public RestartService(StateManager state, ConfigManager config, ScamLog log, OperationLock lock, ExecutorService io,
                          TransactionStore transactions, BackupManager backups, Path updateDir,
                          Supplier<CraftyClient> crafty, Supplier<String> mcVersion) {
        this.state = state;
        this.config = config;
        this.log = log;
        this.lock = lock;
        this.io = io;
        this.transactions = transactions;
        this.backups = backups;
        this.updateDir = updateDir;
        this.crafty = crafty;
        this.mcVersion = mcVersion;
    }

    public CompletableFuture<Outcome> restart(String initiator) {
        CompletableFuture<Outcome> f = new CompletableFuture<>();
        try {
            state.requireActive();
        } catch (IllegalStateException e) {
            f.completeExceptionally(e);
            return f;
        }
        io.submit(() -> {
            try {
                f.complete(run(initiator));
            } catch (Throwable t) {
                log.error("Neustart-Vorgang fehlgeschlagen", t);
                f.completeExceptionally(t);
            }
        });
        return f;
    }

    Outcome run(String initiator) {
        if (!config.crafty().restartEnabled()) return new Outcome(Result.DISABLED, List.of());
        Optional<OperationLock.Handle> handle = lock.tryAcquire("restart");
        if (handle.isEmpty()) return new Outcome(Result.BUSY, List.of(lock.holder()));
        try (OperationLock.Handle h = handle.get()) {
            state.requireActive();
            List<TransactionStore.Pending> pending = transactions.all();
            if (pending.isEmpty() && config.craftyRequirePending()) return new Outcome(Result.NO_PENDING, List.of());
            List<String> problems = preflight(pending);
            if (!problems.isEmpty()) {
                log.warn("Neustart abgebrochen, Vorpruefung fehlgeschlagen: " + String.join("; ", problems));
                return new Outcome(Result.PREFLIGHT_FAILED, problems);
            }
            CraftyClient client = crafty.get();
            if (client == null) return new Outcome(Result.FAILED, List.of("Crafty-Client nicht verfuegbar"));
            log.info("Neustart ueber Crafty angefordert von " + initiator + " (" + pending.size() + " vorgemerkte Aenderung(en)).");
            CraftyClient.Result r = client.restartServer();
            if (r.ok()) {
                log.info("Crafty hat den Neustart angenommen (HTTP " + r.httpStatus() + ").");
                return new Outcome(Result.REQUESTED, List.of());
            }
            log.error("Crafty-Neustart fehlgeschlagen: " + r.status() + " - " + r.message(), null);
            return new Outcome(Result.FAILED, List.of(r.message()));
        }
    }

    /** Pruefpunkte 2-4: Dateien vollstaendig, validiert, Backups vorhanden (5 = Lock, 1 = Bestaetigung vorher). */
    List<String> preflight(List<TransactionStore.Pending> pending) {
        List<String> problems = new ArrayList<>();
        for (TransactionStore.Pending p : pending) {
            try {
                Path staged = AtomicFiles.requireInside(updateDir, p.stagedFile());
                if (!Files.isRegularFile(staged)) { problems.add(p.plugin() + ": Datei in plugins/update fehlt"); continue; }
                if (!Hashing.sha256(staged).equalsIgnoreCase(p.stagedSha256())) { problems.add(p.plugin() + ": Datei wurde veraendert"); continue; }
                JarValidator.validate(staged, p.plugin(), mcVersion.get());
                Optional<BackupManager.Entry> be = backups.get(p.plugin());
                if (be.isEmpty() || !backups.verify(be.get())) problems.add(p.plugin() + ": Backup fehlt oder ist beschaedigt");
            } catch (JarValidator.ValidationException e) {
                problems.add(p.plugin() + ": " + e.getMessage());
            } catch (IOException e) {
                problems.add(p.plugin() + ": " + e.getMessage());
            }
        }
        return problems;
    }
}
